//account.h
#pragma once

struct bank
{
	int flag;
	char name[20];
	int balance;
	char account[20];
	int count;   // Ƚ��
};